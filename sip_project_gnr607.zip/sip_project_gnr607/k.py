import tkinter as tk
from tkinter import filedialog
import cv2
import numpy as np
import matplotlib.pyplot as plt

# Initialize global variables
image = None
transformed_image = None


def upload_image():
    """Allow user to upload an image and process it."""
    global image, transformed_image
    # Open file dialog to select an image
    file_path = filedialog.askopenfilename(
        title="Choose an Image",
        filetypes=[("Image Files", "*.jpg *.jpeg *.png *.bmp *.tiff")]
    )
    if not file_path:
        print("No file selected.")
        return

    # Load the selected image in grayscale
    image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        print("Could not load image!")
        return

    # Transform the image
    rows, cols = image.shape
    affine_matrix = np.float32([[1.2, 0.2, 50], [0.1, 1.1, 30]])
    transformed_image = cv2.warpAffine(image, affine_matrix, (cols, rows))

    # Display the uploaded and transformed images
    plt.figure(figsize=(12, 6))
    plt.subplot(121), plt.title("Original Image"), plt.imshow(image, cmap='gray')
    plt.subplot(122), plt.title("Transformed Image"), plt.imshow(transformed_image, cmap='gray')
    plt.tight_layout()
    plt.show()

    print("Image uploaded and transformed successfully!")


def register_images(image1, image2):
    """Register two images using feature matching and homography."""
    # Step 1: Detect and compute features using ORB
    orb = cv2.ORB_create()
    keypoints1, descriptors1 = orb.detectAndCompute(image1, None)
    keypoints2, descriptors2 = orb.detectAndCompute(image2, None)

    # Step 2: Match features
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = matcher.match(descriptors1, descriptors2)
    matches = sorted(matches, key=lambda x: x.distance)

    # Extract matched keypoints
    points1 = np.float32([keypoints1[m.queryIdx].pt for m in matches])
    points2 = np.float32([keypoints2[m.trainIdx].pt for m in matches])

    # Step 3: Estimate homography
    homography_matrix, _ = cv2.findHomography(points2, points1, cv2.RANSAC, 5.0)

    # Step 4: Warp the second image to align with the first
    height, width = image1.shape[:2]
    registered_image = cv2.warpPerspective(image2, homography_matrix, (width, height))

    # Step 5: Combine the images (optional)
    blended_image = cv2.addWeighted(image1, 0.5, registered_image, 0.5, 0)

    return registered_image, blended_image


def on_register_button_click():
    """Trigger the registration process and display the results."""
    global image, transformed_image
    if image is not None and transformed_image is not None:
        registered_image, blended_image = register_images(image, transformed_image)

        # Display the results
        cv2.imshow("Registered Image", registered_image)
        cv2.imshow("Blended Image", blended_image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    else:
        print("Please upload and process an image first.")


# GUI setup
root = tk.Tk()
root.title("Image Registration")
root.geometry("300x200")

# Add buttons
upload_button = tk.Button(root, text="Upload Image", command=upload_image, width=20, height=2)
upload_button.pack(pady=10)

register_button = tk.Button(root, text="Register Images", command=on_register_button_click, width=20, height=2)
register_button.pack(pady=10)

# Run the GUI event loop
root.mainloop()
